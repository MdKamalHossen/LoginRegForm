//fat arrow function
const sum = ()=>`the multiplication ${(a=10)*(b=2)}`;

console.log(sum());

// array section 

const myFriendsList = ['Rahat',22, true,'Injamam','Mostakin','Atik'];
console.log(myFriendsList);